<?php
	session_start();
	require_once('function.php');
	include 'common/header.php';
	if (isset($_POST['submit'])) {
		$email = $_POST['email'];
		$pass = $_POST['password'];
		$query = "SELECT * FROM user WHERE email ='$email' AND pass = '$pass'";
    $sql = mysqli_query($conn,$query);
		if($row = $sql->fetch_assoc()) {
				$_SESSION['user_id'] = $row['u_id'];
				$_SESSION['user']=$row['name'];
      			$_SESSION['email']=$row['email'];
				$_SESSION['last_time']=time();
				header('location: index.php');
				exit();
			}
	}
 ?>







	<section id="login-form">
		<div class="container text-center">
		    <h2>Login form...</h2>
			<form action="#" method="post">
				<div class="form-group">
					<input type="email" name="email" class="form-control" placeholder="Email">
				</div>
				<div class="form-group">
					<input type="password" name="password" class="form-control" placeholder="Password">
				</div>
				<input type="submit" name="submit" value="Login" class="btn btn-primary"/>
			</form>
		</div>
	</section>
	<div class="login-bottom"></div>
	<?php include 'common/footer.php'; ?>
