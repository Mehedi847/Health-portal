<?php session_start();
   require_once('function.php');
	needLogged();
include 'common/header.php'; 
?>


<?php
if(isset($_SESSION['user']))
{
 if((time() - $_SESSION['last_time']) > 10)
 {
 header("location:logout.php");
 }
 else
 {
 $_SESSION['last_time'] = time();
 //echo "<h1 align='center'>Welcome ".$_SESSION["user"]. "</h1>";
 //echo "<h3 align='center'>Automatic Logout </h3>";
 //echo "<p align='center'><a href='logout.php'>Logout</a></p>";
 }
}
else
{
 header('Location:login.php');
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 10)) {
//     // request 30 seconds ago
  session_destroy();
  session_unset();
     header("location:logout.php");
    }
 $_SESSION['LAST_ACTIVITY'] = time();

// // update last activity time
?>


  <section id="products">
    <div class="container text-center">
			<div class="row">
				<div class="col-md-3">
					<img src="img/apple.jpg" class="img-responsive" alt="">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<p>Price: <span>$1.1</span> </p>
					<a href="#" class="btn btn-primary">Add to cart</a>
				</div>
				<div class="col-md-3">
					<img src="img/fruit2.png" class="img-responsive" alt="">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<p>Price: <span>$1.1</span> </p>
					<a href="#" class="btn btn-primary">Add to cart</a>
				</div>
				<div class="col-md-3">
					<img src="img/fruits3.jpg" class="img-responsive" alt="">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<p>Price: <span>$1.1</span> </p>
					<a href="#" class="btn btn-primary">Add to cart</a>
				</div>
				<div class="col-md-3">
					<img src="img/menu1.png" class="img-responsive" alt="">
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					<p>Price: <span>$1.1</span> </p>
					<a href="#" class="btn btn-primary">Add to cart</a>
				</div>
			</div>
    </div>
  </section>
<?php include 'common/footer.php'; ?>
