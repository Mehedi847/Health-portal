<?php session_start();
   require_once('function.php');
	needLogged();

   include 'common/header.php';
 ?>




 <?php
if(isset($_SESSION['user']))
{
 if((time() - $_SESSION['last_time']) > 10)
 {
 header("location:logout.php");
 }
 else
 {
 $_SESSION['last_time'] = time();
 //echo "<h1 align='center'>Welcome ".$_SESSION["user"]. "</h1>";
 //echo "<h3 align='center'>Automatic Logout </h3>";
 //echo "<p align='center'><a href='logout.php'>Logout</a></p>";
 }
}
else
{
 header('Location:login.php');
}
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 10)) {
//     // request 30 seconds ago
  session_destroy();
  session_unset();
     header("location:logout.php");
    }
 $_SESSION['LAST_ACTIVITY'] = time();

// // update last activity time
?>



	<section>
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		  <!-- Indicators -->
		  <ol class="carousel-indicators">
		    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
		    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
		    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
		  </ol>

		  <!-- Wrapper for slides -->
		  <div class="carousel-inner" role="listbox">
		    <div class="item active">
		      <img src="img/slide1.jpg" alt="...">
		      <div class="carousel-caption">
		      	<h1><span>Welcome</span> to Health Portal</h1>
		      </div>
		    </div>
		    <div class="item">
		      <img src="img/slide2.jpg" alt="...">
		      <div class="carousel-caption">
		        <h1><span>Welcome</span> to Health Portal</h1>
		      </div>
		    </div>
		    <div class="item">
		      <img src="img/slide3.jpg" alt="...">
		      <div class="carousel-caption">
		        <h1><span>Welcome</span> to Health Portal</h1>
		      </div>
		    </div>
		  </div>

		  <!-- Controls -->
		  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
		    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
		    <span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
		    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
		    <span class="sr-only">Next</span>
		  </a>
		</div>
	</section>

	<section id="disease-search">
		<div class="container text-center">
		    <h2>Enter your disease</h2>
			<form method="get" action="searchresult.php">
          <input type="text" placeholder="Your Diseases" name="search" />
          <input type="submit" value="search" />
          </form>
		</div>
	</section>

<?php
    include 'common/footer.php';
 ?>
