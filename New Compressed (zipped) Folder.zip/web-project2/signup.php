<?php
  session_start();
  include 'config/conn.php';
	include 'common/header.php';
	if (isset($_POST['submit'])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$age = $_POST['age'];
		$pass = $_POST['password'];
		$query = "INSERT INTO user (name,email,age,pass) VALUES ('$name','$email', '$age', '$pass')";
		$sql = mysqli_query($conn, $query);
		if (!$sql) {
			echo "signup error";
		} else {
		  header('location:login.php');
		}
	}
 ?>
	<section id="login-form">
		<div class="container text-center">
		    <h2>Signup here...</h2>
			<form action="" method="POST">
			    <div class="form-group">
					<input type="text" name="name" class="form-control" placeholder="name">
				</div>
				<div class="form-group">
					<input type="email" name="email" class="form-control" placeholder="email">
				</div>
				<div class="form-group">
					<input type="text" name="age" class="form-control" placeholder="age">
				</div>
				<div class="form-group">
					<input type="password" name="password" class="form-control" placeholder="Password">
				</div>
				<div class="form-group">
					<input type="password" name="conpass" class="form-control" placeholder="Confirm Password">
				</div>
				<button type="submit" name="submit" class="btn btn-primary">Login</button>
			</form>
		</div>
	</section>
	<div class="login-bottom"></div>
	<?php
		include 'common/footer.php';
	 ?>
