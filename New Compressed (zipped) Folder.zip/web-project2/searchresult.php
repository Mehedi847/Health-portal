<?php session_start();
   require_once('function.php');
  needLogged();
  include 'common/header.php';

      $search=$_GET['search'];
      $sel="select * from fruits natural join disease where diseases_name like '%$search%' or suggested_hospital like '%$search%'";
      $qry=mysqli_query($conn,$sel);
      while($data=mysqli_fetch_array($qry)){
?>

    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <section id="disease-search">
            <div class="container text-center">
                <h2>Enter your Location</h2>
              <form method="get" action="locationsearch.php">
                  <input type="text" placeholder="Your Location" name="search" />
                  <input type="submit" value="search" />
                  </form>
            </div>
          </section>
  </div>
  </div>
</div>

    <div class="container">
      <div class="row">
        <div class="col-md-3" style="border: 1px solid #444; padding: 10px">
          <h2 class="text-center">You can buy these from our shop</h2>
          <img src="img/<?=$data['imgpath'];?>" class="img-responsive">
          <h4>Fruits Name : <?=$data['name'];?> </h4>
          <p>Description : <?=$data['f_desc'];?></p>
          <p>Price:$ <?=$data['price'];?></p>
          <p>Calories: <?=$data['calorie'];?></p>
          <a href="#" class="btn btn-success">Buy Now</a>
        </div>
      </div>
    </div>


        <?php
            }

      ?>
  <?php include 'common/footer.php'; ?>
