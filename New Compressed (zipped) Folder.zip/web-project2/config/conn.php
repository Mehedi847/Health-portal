<?php
   $conn = mysqli_connect('localhost', 'root', '', 'health');
   if (!$conn) {
     echo "Database connection error";
   }
 ?>
