-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2018 at 07:16 AM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health-portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `disease`
--

CREATE TABLE `disease` (
  `diseases_id` int(11) NOT NULL,
  `diseases_name` varchar(50) NOT NULL,
  `suggested_hospital` varchar(200) NOT NULL,
  `Doctor` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `disease`
--

INSERT INTO `disease` (`diseases_id`, `diseases_name`, `suggested_hospital`, `Doctor`) VALUES
(1, 'fever', 'Sir solimullah medicale college hospital', 'Abul Mal Abdul Muhit'),
(2, 'Head hadac', 'Popular diagnosis center', 'Abul Kalam Ajad');

-- --------------------------------------------------------

--
-- Table structure for table `disease_fruits_herbs`
--

CREATE TABLE `disease_fruits_herbs` (
  `d_id` int(11) NOT NULL,
  `f_id` int(11) NOT NULL,
  `h_id` int(11) NOT NULL,
  `did` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fruits`
--

CREATE TABLE `fruits` (
  `f_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `f_desc` text NOT NULL,
  `imgpath` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `calorie` varchar(50) NOT NULL,
  `diseases_name` varchar(200) NOT NULL,
  `diseases_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fruits`
--

INSERT INTO `fruits` (`f_id`, `name`, `f_desc`, `imgpath`, `price`, `calorie`, `diseases_name`, `diseases_id`) VALUES
(1, 'Apple', 'Description : Total Fat 0.2 g alories 52 per 100 g aturated fat 0 g olyunsaturated fat 0.1 g odium 1 mg,Potassium 107 mg otal Carbohydrate 14 g rotein 0.3 g,Vitamin A: 1% Total Fat 0.2 g alories 52 per 100 g aturated fat 0 g olyunsaturated fat 0.1 g odium 1 mg,Potassium 107 mg otal Carbohydrate 14 g rotein 0.3 g,Vitamin A: 1% Total Fat 0.2 g alories 52 per 100 g aturated fat 0 g olyunsaturated fat 0.1 g odium 1 mg,Potassium 107 mg otal Carbohydrate 14 g rotein 0.3 g,Vitamin A: 1% Total Fat 0.2 g alories 52 per 100 g aturated fat 0 g olyunsaturated fat 0.1 g odium 1 mg,Potassium 107 mg otal Carbohydrate 14 g rotein 0.3 g,Vitamin A: 1% ', 'apple.jpg', 20, '71Kcal', 'fever', 1),
(2, 'Malta', 'Description : Description : Total Fat 0.2 g alories 52 per 100 g aturated fat 0 g olyunsaturated fat 0.1 g odium 1 mg,Potassium 107 mg otal Carbohydrate 14 g rotein 0.3 g,Vitamin A: 1% Total Fat 0.2 g alories 52 per 100 g aturated fat 0 g olyunsaturated fat 0.1 g odium 1 mg,Potassium 107 mg otal Carbohydrate 14 g rotein 0.3 g,Vitamin A: 1% Total Fat 0.2 g alories 52 per 100 g aturated fat 0 g olyunsaturated fat 0.1 g odium 1 ', 'fruit2.png', 200, '175kcal', 'head hadac', 2);

-- --------------------------------------------------------

--
-- Table structure for table `herbs`
--

CREATE TABLE `herbs` (
  `h_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `h_desc` text NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospital_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `did` int(11) NOT NULL,
  `location` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `u_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `name`, `email`, `age`, `pass`) VALUES
(1, 'Shakil', 'email@email.com', '20', '12345'),
(2, 'Shihab', 'shihab@shihab.com', '22', '12345'),
(3, 'fdf', 'fdjfkdj@dfjdf.com', '22', '1121212'),
(4, 'fsfasdas', 'dsdsdsd@fdfdf', '22', '4232323'),
(5, 'shakil khan', 'shakil11@gmail.com', '22', '12345'),
(6, 'mehedi', 'mehedi@gmail.com', '23', '12345'),
(7, 'rafikul islam', 'raju@gmail.com', '25', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `disease`
--
ALTER TABLE `disease`
  ADD PRIMARY KEY (`diseases_id`);

--
-- Indexes for table `disease_fruits_herbs`
--
ALTER TABLE `disease_fruits_herbs`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `fruits`
--
ALTER TABLE `fruits`
  ADD PRIMARY KEY (`f_id`),
  ADD KEY `diseases_id` (`diseases_id`);

--
-- Indexes for table `herbs`
--
ALTER TABLE `herbs`
  ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `disease`
--
ALTER TABLE `disease`
  MODIFY `diseases_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `disease_fruits_herbs`
--
ALTER TABLE `disease_fruits_herbs`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fruits`
--
ALTER TABLE `fruits`
  MODIFY `f_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `herbs`
--
ALTER TABLE `herbs`
  MODIFY `h_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `fruits`
--
ALTER TABLE `fruits`
  ADD CONSTRAINT `fruits_ibfk_1` FOREIGN KEY (`diseases_id`) REFERENCES `disease` (`diseases_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
